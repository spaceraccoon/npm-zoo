module.exports = require('./build/StreamCombine');
